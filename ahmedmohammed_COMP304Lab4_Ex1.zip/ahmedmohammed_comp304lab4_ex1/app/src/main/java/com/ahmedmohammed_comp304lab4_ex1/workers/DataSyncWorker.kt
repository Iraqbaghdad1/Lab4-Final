package com.ahmedmohammed_comp304lab4_ex1.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.ahmedmohammed_comp304lab4_ex1.model.LocationDao
import kotlinx.coroutines.delay
import timber.log.Timber
import javax.inject.Inject

class SyncWorker @Inject constructor(
    private val locationDao: LocationDao,
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val locations = locationDao.getAllLocations()
            locations.forEach { location ->

                Timber.d("Syncing location: $location")
                delay(500)
            }
            Result.success()
        } catch (e: Exception) {
            Timber.e("Error syncing locations: ${e.localizedMessage}")
            Result.retry()
        }
    }
}