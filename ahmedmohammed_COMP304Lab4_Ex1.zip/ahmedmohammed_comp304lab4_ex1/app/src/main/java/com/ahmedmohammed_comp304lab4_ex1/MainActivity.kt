package com.ahmedmohammed_comp304lab4_ex1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModelProvider
import com.ahmedmohammed_comp304lab4_ex1.ui.theme.Ahmedmohammed_comp304lab4_ex1Theme
import com.ahmedmohammed_comp304lab4_ex1.utils.ManifestUtils
import com.ahmedmohammed_comp304lab4_ex1.view.MapScreen
import com.ahmedmohammed_comp304lab4_ex1.viewmodel.MapScreenViewModel
import com.google.android.libraries.places.api.Places
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val apiKey = ManifestUtils.getApiKeyFromManifest(this)

        if (!Places.isInitialized() && apiKey != null) {
            Places.initialize(applicationContext, apiKey)
        }

        enableEdgeToEdge()

        val mapScreenViewModel = ViewModelProvider(this)[MapScreenViewModel::class.java]

        setContent {

            Ahmedmohammed_comp304lab4_ex1Theme {

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->

                    MapScreen(mapViewModel = mapScreenViewModel , modifier = Modifier.padding(innerPadding))

                }
            }
        }
    }
}

