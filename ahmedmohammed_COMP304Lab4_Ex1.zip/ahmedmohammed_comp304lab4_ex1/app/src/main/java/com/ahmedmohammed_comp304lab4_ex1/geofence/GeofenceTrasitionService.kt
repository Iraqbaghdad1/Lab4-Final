package com.ahmedmohammed_comp304lab4_ex1.geofence

import android.app.IntentService
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import timber.log.Timber

class GeofenceTransitionService : IntentService("GeofenceTransitionService") {
    override fun onHandleIntent(intent: Intent?) {
        val geofencingEvent = GeofencingEvent.fromIntent(intent!!)
        if (geofencingEvent != null) {
            if (geofencingEvent.hasError()) {
                val errorCode = geofencingEvent.errorCode
                Timber.e("Geofence error: $errorCode")
                return
            }
        }
        // Handle geofence transitions (ENTER/EXIT)
        val transition = geofencingEvent?.geofenceTransition
        if (transition == Geofence.GEOFENCE_TRANSITION_ENTER) {
            Timber.d("Entered geofence")
            // Handle enter logic
        } else if (transition == Geofence.GEOFENCE_TRANSITION_EXIT) {
            Timber.d("Exited geofence")
            // Handle exit logic
        }
    }
}
