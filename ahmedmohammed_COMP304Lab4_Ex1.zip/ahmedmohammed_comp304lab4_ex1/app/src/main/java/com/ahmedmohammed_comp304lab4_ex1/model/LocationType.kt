package com.ahmedmohammed_comp304lab4_ex1.model

enum class LocationType {
    USER, SELECTED , CUSTOM
}